# 🎯 Placement Prediction using Machine Learning

## 🔍 Objective:
Predict whether a student will get placed based on CGPA, IQ, and gender using ML models and tuning.

---

## 📦 Technologies Used:
- pandas
- scikit-learn (GridSearchCV, RandomForest)
- get_dummies (for one-hot encoding)

---

## 🧠 Features:
- Input: `cgpa`, `iq`, `gender`
- Target: `placed` (yes/no → 1/0)

---

## 🚀 Models Used:
- Random Forest Classifier (with GridSearchCV for tuning)

---

## ✅ Results:
- Tuned model using cross-validation
- Accuracy: ~95% (varies by data)
- Best Parameters printed using `grid_search.best_params_`

---

## 📌 Improvements:
- Used `get_dummies()` for gender encoding
- Applied `GridSearchCV` for automatic parameter tuning
- Can be deployed using Flask or Streamlit

