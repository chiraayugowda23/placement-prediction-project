# Placement Prediction using ML (with get_dummies and GridSearchCV)

import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

# Step 1: Load dataset
df = pd.read_excel("placement_data.xlsx")

# Step 2: One-hot encode 'gender'
df = pd.get_dummies(df, columns=['gender'], drop_first=True)

# Step 3: Define features and target
X = df[['cgpa', 'iq', 'gender_male']]  # 'gender_male' is the dummy variable
y = df['placed']

# Step 4: Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 5: Define Random Forest + tuning parameters
model = RandomForestClassifier(random_state=42)
param_grid = {
    'n_estimators': [50, 100, 150],
    'max_depth': [None, 5, 10],
    'min_samples_split': [2, 5]
}

# Step 6: Grid Search CV
grid_search = GridSearchCV(model, param_grid, cv=3, scoring='accuracy', verbose=1, n_jobs=-1)
grid_search.fit(X_train, y_train)

# Step 7: Evaluation
y_pred = grid_search.predict(X_test)
print("✅ Best Parameters:", grid_search.best_params_)
print("✅ Accuracy Score:", accuracy_score(y_test, y_pred))
print("\n📊 Classification Report:\n", classification_report(y_test, y_pred))
